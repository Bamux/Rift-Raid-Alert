import os
import time
import win32com.client
import pythoncom
import winsound
import codecs
import win32clipboard
from threading import Thread


def logfile_check():  # Überprüft ob eine Log.txt Datei vorhanden ist
    try:
        logtext = codecs.open("Log.txt", 'r', "utf-8")
    except:
        try:
            logfile = os.path.expanduser('~\Documents\RIFT\Log.txt')
            logtext = codecs.open(logfile, 'r', "utf-8")
        except:
            try:
                logfile = 'C:\Program Files (x86)\RIFT Game\Log.txt'
                logtext = codecs.open(logfile, 'r', "utf-8")
            except:
                try:
                    logfile = 'C:\Programs\RIFT~1\Log.txt'
                    logtext = codecs.open(logfile, 'r', "utf-8")
                except:
                    print('Error! could not find the Log File')
                    print('use /log in Rift and edit the path to your Logfile (Settings).')
                    print('Restart the Rift Raid Alert after your edit the path to your Log.txt!')
    if logtext:
        logfile_analysis(logtext)


def logfile_analysis(logtext):  # analysiert jede neue Zeile in der Log.txt
    logtext.seek(0, 2)  # springt ans Ende der Log.txt
    playername_list = []
    while True:
        line = logtext.readline()  # neue Zeile einlesen
        log = str.lower(line)  # alles in Kleinbuchstaben
        if log:
            if "lfm" in log:
                if "rr" in log or "Lure: The Iron Legion" in log or "Lure: Decay of Ahnket" in log or "Lure: Egg of Destruction" in log:
                    try:
                        playername = line.split("]: ")[0]
                        playername = playername.split("][")[1]
                        playername_existing = False
                        for item in playername_list:  # überprüft ob für diesen Spieler die Sounddatei bereits abgespielt wurde um eine Wiederholung zu verhindern
                            if item == playername:
                                playername_existing = True
                                break
                        if not playername_existing:
                            playername_list += [playername]
                            Thread(target=play_sound, args=("RaidRift.wav",)).start()  # spiel die Sounddatei RaidRift.wav ab
                            text = "/tell " + playername + " + "
                            clipboard(text)  # Text wird in die Zwischenablage kopiert
                            print(time.strftime("%H:%M:%S") + " - " + playername)
                            print(line)
                    except:
                            pass
            elif "entered a raid group" in line or "Ihr seid einem Schlachtzug beigetreten" in line:
                    os._exit(1)

        else:
            time.sleep(0.50)  # wartet auf eine neue Eingabe in der Loc.txt


def clipboard(text):  # Text wird in die Zwischenablage kopiert
    win32clipboard.OpenClipboard()
    win32clipboard.EmptyClipboard()
    win32clipboard.SetClipboardText(text, win32clipboard.CF_UNICODETEXT)
    win32clipboard.CloseClipboard()


def play_sound(file):
    winsound.PlaySound(file, winsound.SND_FILENAME)


print("RaidRift_v0.1")
logfile_check()
